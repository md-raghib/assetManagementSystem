package com.csc.service;

import java.util.ArrayList;

import com.csc.bean.Request;
import com.csc.bean.Transfer;
import com.csc.bean.UserAsset;
import com.csc.bean.ViewAsset;
import com.csc.dao.EmployeeDAO;

public class EmployeeService {
	public boolean requestAsset(Request request)
	{
		EmployeeDAO.connect();
		boolean b= EmployeeDAO.requestAsset(request);
		if(b){
		return true;
		}
		else
			return false;
		
	}
	
	public boolean transferAsset(Transfer trans)
	{
		EmployeeDAO.connect();
		boolean b= EmployeeDAO.transferAsset(trans);
		if(b){
		return true;
		}
		else
			return false;
		
	}
	
	public ArrayList<Request> displayStatus(Request request) {
		
		EmployeeDAO.connect();
		ArrayList<Request> al= EmployeeDAO.displayRequestStatus(request);
		return al;
	}
	
	
public ArrayList<ViewAsset> displayAsset(UserAsset va ) {
		
		EmployeeDAO.connect();
		ArrayList<ViewAsset> al= EmployeeDAO.displayViewAsset(va);
		return al;
	}


}
