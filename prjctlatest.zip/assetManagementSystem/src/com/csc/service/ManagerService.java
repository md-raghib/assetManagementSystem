package com.csc.service;

import java.util.ArrayList;

import com.csc.bean.Request;
import com.csc.bean.UserAsset;
import com.csc.bean.ViewAsset;
import com.csc.bean.ViewTeam;
import com.csc.dao.ManagerDAO;

public class ManagerService {
	public boolean requestAsset(Request request)
	{
		ManagerDAO.connect();
		boolean b= ManagerDAO.requestAsset(request);
		if(b){
		return true;
		}
		else
			return false;
}
public ArrayList<Request> displayStatus(Request request) {
		
		ManagerDAO.connect();
		ArrayList<Request> al= ManagerDAO.displayRequestStatus(request);
		return al;
	}	

public ArrayList<ViewAsset> displayAsset(UserAsset ua) {
	
	ManagerDAO.connect();
	ArrayList<ViewAsset> al= ManagerDAO.displayViewAsset(ua);
	return al;
}


public ArrayList<Request> displayRequests(Request request) {
	
	ManagerDAO.connect();
	ArrayList<Request> al= ManagerDAO.displayEmployeeRequests(request);
	return al;
}	


public ArrayList<ViewTeam> displayTeam(UserAsset ua) {
	
	ManagerDAO.connect();
	ArrayList<ViewTeam> al= ManagerDAO.displayViewTeam(ua);
	return al;
}	
public boolean updateRequest(Request request) {
	ManagerDAO.connect();
	boolean b=ManagerDAO.updateRequest(request);
	if(b){

		return true;
}

else	{
	return false;
} 

}

public boolean rejectRequest(Request request) {
	ManagerDAO.connect();
	boolean b=ManagerDAO.rejectRequest(request);
	if(b){

		return true;
}

else	{
	return false;
} 
}	
}
