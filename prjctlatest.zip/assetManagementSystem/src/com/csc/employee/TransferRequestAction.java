package com.csc.employee;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.Asset;
import com.csc.bean.Transfer;
import com.csc.bean.User;
import com.csc.service.EmployeeService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings("rawtypes")
public class TransferRequestAction extends ActionSupport implements ModelDriven,ServletRequestAware{

	private static final long serialVersionUID = 1L;
	HttpSession session;
	
	Transfer trans=new Transfer();
	
	
	public Transfer getTrans() {
		return trans;
	}
	public void setTrans(Transfer trans) {
		this.trans = trans;
	}
	
	public void setServletTransfer(HttpServletRequest trans) {
		this.session = trans.getSession();
	}

	@Override
	public Object getModel() {
		
		return trans;
	}
	public String execute() {
		
		User user=new User();
		
		user.setUserId((int) session.getAttribute("uid"));
		Asset asset=new Asset();
		asset.setAssetName((String)session.getAttribute("aname"));
		EmployeeService as=new EmployeeService();
		if((as.transferAsset(trans))!=false){
			return SUCCESS;
		}
		else
			return ERROR;
		
	}
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	} 

}
