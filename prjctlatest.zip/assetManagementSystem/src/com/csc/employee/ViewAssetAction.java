package com.csc.employee;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.UserAsset;
import com.csc.bean.ViewAsset;
import com.csc.service.EmployeeService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ViewAssetAction extends ActionSupport implements ModelDriven,ServletRequestAware{
ArrayList<ViewAsset> viewasset=new ArrayList<>();
UserAsset va=new UserAsset();


	HttpSession session;
	public ArrayList<ViewAsset> getViewasset() {
	return viewasset;
}
public void setViewasset(ArrayList<ViewAsset> viewasset) {
	this.viewasset = viewasset;
}
	@Override
	public Object getModel() {
		
		return viewasset;
	}
	public String execute() {
		EmployeeService as=new EmployeeService();
		va.setUserId((int)session.getAttribute("uid"));
		
		viewasset=as.displayAsset(va);
		session.setAttribute("aid", viewasset.get(0).getAssetId());
		session.setAttribute("aname", viewasset.get(0).getAssetName());
		
			return SUCCESS;
		
		
	}
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	}
}
