
 function login_val()
   {
	
   var email=document.getElementById('email').value;
   var password=document.getElementById('password').value;
   
   
   
   var msg=document.getElementById('msg');
   
   
   
   
   var reg_email=/^[a-z,A-Z,0-9,.,-,_,#]+[@][a-z,A-Z,0-9,.]+[.][a-z,A-Z,.]{1,3}$/;
   var var_password=/^[a-z]{1,10}$/;
   
    if(email=='')
   {
	msg.innerHTML="Please Enter Email Id";
	   return false;   
   }
   else if(!email.match(reg_email))
   {
	msg.innerHTML="Please Enter Valid email";
	   return false;   
   }
  
  
   else if(password=='')
   {
	msg.innerHTML="Please Enter Password";
	   return false;   
   }
   else if(!password.match(var_password))
   {
	msg.innerHTML="Please Enter Valid Password";
	   return false;   
   }
  
   else{
	   return true;
	   } 
   }
// JavaScript Document