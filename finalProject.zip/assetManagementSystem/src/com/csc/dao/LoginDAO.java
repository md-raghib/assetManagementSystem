package com.csc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.csc.bean.User;

public class LoginDAO {

	private static Connection conn;

	

	public static void connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager
					.getConnection("jdbc:mysql://localhost/ams?"+"user=root&password=cscindia@123");
		} catch (ClassNotFoundException ce) {
			ce.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}// connect

	public static User loginUser(User user) {
		PreparedStatement pmt = null;
		ResultSet rs=null;
		try {
			pmt = conn.prepareStatement("select * from user where email=? and password=?");
			System.out.println("email="+user.getEmail());
			System.out.println("password"+user.getPassword());
			pmt.setString(1, user.getEmail());
			pmt.setString(2, user.getPassword());
			rs=pmt.executeQuery();
			while(rs.next()){
				
				if(rs.getString(11).equals("employee")){
					user.setUserId(rs.getInt(1));
					user.setManagerId(rs.getInt(2));
					user.setFirstName(rs.getString(3));
					user.setLastName(rs.getString(4));
					user.setEmail(rs.getString(5));
					user.setPassword(rs.getString(6));
					user.setShortId(rs.getString(7));
					user.setMobileNumber(rs.getString(8));
					user.setDateOfJoining(rs.getString(9));
					user.setIsActive(rs.getString(10));
					user.setUserType(rs.getString(11));
				
					return user;
					
				}
				else if(rs.getString(11).equals("manager")){
					user.setUserId(rs.getInt(1));
					user.setManagerId(rs.getInt(2));
					user.setFirstName(rs.getString(3));
					user.setLastName(rs.getString(4));
					user.setEmail(rs.getString(5));
					user.setPassword(rs.getString(6));
					user.setShortId(rs.getString(7));
					user.setMobileNumber(rs.getString(8));
					user.setDateOfJoining(rs.getString(9));
					user.setIsActive(rs.getString(10));
					user.setUserType(rs.getString(11));
				
					return user;
				}
				else if(rs.getString(11).equals("admin")){
					user.setUserId(rs.getInt(1));
					user.setManagerId(rs.getInt(2));
					user.setFirstName(rs.getString(3));
					user.setLastName(rs.getString(4));
					user.setEmail(rs.getString(5));
					user.setPassword(rs.getString(6));
					user.setShortId(rs.getString(7));
					user.setMobileNumber(rs.getString(8));
					user.setDateOfJoining(rs.getString(9));
					user.setIsActive(rs.getString(10));
					user.setUserType(rs.getString(11));
				
					return user;
				}
				else if(rs.getString(11).equals("support")){
					user.setUserId(rs.getInt(1));
					user.setManagerId(rs.getInt(2));
					user.setFirstName(rs.getString(3));
					user.setLastName(rs.getString(4));
					user.setEmail(rs.getString(5));
					user.setPassword(rs.getString(6));
					user.setShortId(rs.getString(7));
					user.setMobileNumber(rs.getString(8));
					user.setDateOfJoining(rs.getString(9));
					user.setIsActive(rs.getString(10));
					user.setUserType(rs.getString(11));
				
					return user;
				}
				else{
					return null;
				}
				
			}
			
			
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				if (pmt != null) {
					pmt.close();
				}

				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return null;
	}// createUser

	
}
