package com.csc.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.User;
import com.csc.service.AdminService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ModifyUserAction extends ActionSupport implements ModelDriven,ServletRequestAware {
		
	User user=new User();
	HttpSession session;
	@Override
	public Object getModel() {
		
		return user;
	}
	
	public String execute() {
		AdminService as=new AdminService();
		user.setUserId((int) session.getAttribute("uid"));
		if((as.update(user))!=false){
			return SUCCESS;
		}
		else
			return ERROR;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	}
	
	
	
}
