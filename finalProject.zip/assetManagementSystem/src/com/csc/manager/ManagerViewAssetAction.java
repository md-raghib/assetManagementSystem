package com.csc.manager;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.*;
import com.csc.service.*;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ManagerViewAssetAction extends ActionSupport implements ModelDriven,ServletRequestAware{
	HttpSession session;
	ArrayList<ViewAsset> viewasset=new ArrayList<>();
   UserAsset ua=new UserAsset();
   
	
	public ArrayList<ViewAsset> getViewasset() {
	return viewasset;
}
public void setViewasset(ArrayList<ViewAsset> viewasset) {
	this.viewasset = viewasset;
}
	@Override
	public Object getModel() {
		
		return viewasset;
	}
	public String execute() {
		ManagerService as=new ManagerService();
		ua.setUserId((int)session.getAttribute("uid"));
		viewasset=as.displayAsset(ua);
		
			return SUCCESS;
		
		
	}
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	}
}
