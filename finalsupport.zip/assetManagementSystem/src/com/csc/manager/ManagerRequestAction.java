package com.csc.manager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.Request;
import com.csc.service.*;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings("rawtypes")
public class ManagerRequestAction extends ActionSupport implements ModelDriven,ServletRequestAware{
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	HttpSession session;
	Request request=new Request();
	
	@Override
	public Object getModel() {
		
		return request;
	}
	public String execute() {
		session.getAttribute("uid");
		request.setUserId((int) session.getAttribute("uid"));
		ManagerService as=new ManagerService();
		if((as.requestAsset(request))!=false){
			return SUCCESS;
		}
		else
			return ERROR;
		
	}
	
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	}}

