package com.csc.manager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.Request;
import com.csc.service.ManagerService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings("serial")
public class ManagerRejectRequestAction extends ActionSupport implements ModelDriven,ServletRequestAware{

	HttpSession session;
	Request request=new Request();

	public Request getRequest() {
		//System.out.println(request);
		return request;
	}

	public void setRequest(Request request) {
		this.request = request;
	}

	public void setServletRequest(HttpServletRequest request) {
		this.session = request.getSession();
	}
	 public String execute() {
		 request.setRequestId((int)session.getAttribute("rid"));
			ManagerService ms=new ManagerService();
				if(ms.rejectRequest(request))
				return SUCCESS;
				else
					return ERROR;
			}
		
		@Override
		public Object getModel() {
			
			return request;
		}
}
