package com.csc.manager;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.UserAsset;
import com.csc.bean.ViewTeam;
import com.csc.service.ManagerService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ManagerViewTeamAction extends ActionSupport implements ModelDriven,ServletRequestAware{

ArrayList<ViewTeam> teamList=new ArrayList<>();
	UserAsset ua=new UserAsset();
	HttpSession session;
	
	
	public ArrayList<ViewTeam> getTeamList() {
	return teamList;
}
public void setTeamList(ArrayList<ViewTeam> teamList) {
	this.teamList = teamList;
}
	public String execute() {
		ManagerService rs=new ManagerService();
		ua.setUserId((int)session.getAttribute("uid"));
		teamList=rs.displayTeam(ua);
	
	
		return SUCCESS;
	}
	@Override
	public Object getModel() {
		
		return teamList;
	}
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	}
	
}


