package com.csc.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.User;
import com.csc.service.LoginService;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "rawtypes" })
public class LoginAction  implements ServletRequestAware, ModelDriven {

	User user = new User();
	HttpSession session;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	
	public Object getModel() {

		return user;
	}

	public String execute() {
		LoginService ls = new LoginService();
		User au = ls.log(user);
		
		
		
		au.setUserId(user.getUserId());
		au.setFirstName(user.getFirstName());
		au.setEmail(user.getEmail());
		
		
		
		
		
		
		
		if(user.getUserType().equals("employee")){
			session.setAttribute("uid", au.getUserId());
			session.setAttribute("name", au.getFirstName());
			
			return "employee";
		}
		else if(user.getUserType().equals("manager")){
			session.setAttribute("uid", au.getUserId());
			session.setAttribute("name", au.getFirstName());
			
			return "manager";
		}
		else if(user.getUserType().equals("admin")){
			session.setAttribute("uid", au.getUserId());
			session.setAttribute("name", au.getFirstName());
			
			return "admin";
		}
		else
			session.setAttribute("uid", au.getUserId());
		session.setAttribute("name", au.getFirstName());
		
			return "error";

	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	}

}
