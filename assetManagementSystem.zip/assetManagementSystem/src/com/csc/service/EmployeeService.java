package com.csc.service;

import java.util.ArrayList;

import com.csc.bean.Request;
import com.csc.bean.ViewAsset;
import com.csc.dao.EmployeeDAO;

public class EmployeeService {
	public boolean requestAsset(Request request)
	{
		EmployeeDAO.connect();
		boolean b= EmployeeDAO.requestAsset(request);
		if(b){
		return true;
		}
		else
			return false;
		
	}
	
	public ArrayList<Request> displayStatus() {
		
		EmployeeDAO.connect();
		ArrayList<Request> al= EmployeeDAO.displayRequestStatus();
		return al;
	}
	
	
public ArrayList<ViewAsset> displayAsset() {
		
		EmployeeDAO.connect();
		ArrayList<ViewAsset> al= EmployeeDAO.displayViewAsset();
		return al;
	}


}
