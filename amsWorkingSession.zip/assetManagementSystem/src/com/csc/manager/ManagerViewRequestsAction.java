package com.csc.manager;

import java.util.ArrayList;

import com.csc.bean.Request;
import com.csc.bean.ViewTeam;
import com.csc.service.ManagerService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings("serial")
public class ManagerViewRequestsAction extends ActionSupport implements ModelDriven{

ArrayList<Request> requestList=new ArrayList<>();
	
	
	
	public ArrayList<Request> getRequestList() {
	return requestList;
}
public void setRequestList(ArrayList<Request> teamList) {
	this.requestList = requestList;
}
	public String execute() {
		ManagerService rs=new ManagerService();
		requestList=rs.displayRequests();
	
	
		return SUCCESS;
	}
	@Override
	public Object getModel() {
		
		return requestList;
	}
}
