package com.csc.manager;

import java.util.ArrayList;

import com.csc.bean.Request;
import com.csc.bean.ViewTeam;
import com.csc.service.ManagerService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ManagerViewTeamAction extends ActionSupport implements ModelDriven{

ArrayList<ViewTeam> teamList=new ArrayList<>();
	
	
	
	public ArrayList<ViewTeam> getTeamList() {
	return teamList;
}
public void setTeamList(ArrayList<ViewTeam> teamList) {
	this.teamList = teamList;
}
	public String execute() {
		ManagerService rs=new ManagerService();
		teamList=rs.displayTeam();
	
	
		return SUCCESS;
	}
	@Override
	public Object getModel() {
		
		return teamList;
	}
	
}


