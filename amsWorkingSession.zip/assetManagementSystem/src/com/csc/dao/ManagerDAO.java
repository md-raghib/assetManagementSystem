package com.csc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import com.csc.bean.Request;
import com.csc.bean.ViewAsset;
import com.csc.bean.ViewTeam;

public class ManagerDAO {
private static Connection conn;
	
	public ManagerDAO(){}
	
	public static void connect()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
	        conn=DriverManager.getConnection("jdbc:mysql://localhost/asmproject?"+"user=root&password=root");
		}
		catch(ClassNotFoundException ce){
			ce.printStackTrace();
		}
		catch(SQLException se){
			se.printStackTrace();
		}
	}//connect
	
	public static boolean requestAsset(Request request){
		PreparedStatement pmt=null;
		
		try{
			 pmt=conn.prepareStatement("insert into request2(user_id,asset_name) values(?,?)");
			pmt.setInt(1, request.getUserId());
			pmt.setString(2, request.getAssetName());
		
			int n=pmt.executeUpdate();
			if(n>0)
				return true;
		}catch(SQLException se){
			se.printStackTrace();
		}finally{
			try{
				if( pmt!=null){
					pmt.close();
				}
				
				if(conn!=null){
					conn.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return false;
	}//createUser

public static ArrayList<Request> displayRequestStatus() {
		
		try{
			String query="Select * from request2";
			PreparedStatement pmt=conn.prepareStatement(query);
			ResultSet rs=pmt.executeQuery();
			ArrayList<Request> al=new ArrayList<>();
			while(rs.next()){
				Request request=new Request();
				request.setRequestId(rs.getInt(1));
				request.setUserId(rs.getInt(2));
				request.setStatus(rs.getString(3));
				request.setType(rs.getString(4));
				request.setAssetName(rs.getString(5));
				request.setRemarks(rs.getString(6));
				request.setRequestDate(rs.getString(7));
				request.setResponseDate(rs.getString(8));
				
				al.add(request);
				
				
			}
			return al;
			
			
		}catch(SQLException se){
			se.printStackTrace();
		}
		return null;
		
	}

public static ArrayList<ViewAsset> displayViewAsset() {
	
	try{
		String query="select user_asset.asset_id, asset2.asset_name from asset2 inner join user_asset on user_asset.asset_id=asset2.asset_id where user_asset.user_id=101";
		PreparedStatement pmt=conn.prepareStatement(query);
		ResultSet rs=pmt.executeQuery();
		ArrayList<ViewAsset> al=new ArrayList<>();
		while(rs.next()){
			ViewAsset viewasset=new ViewAsset();
			/*System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));*/
			viewasset.setAssetId(rs.getInt(1));
			viewasset.setAssetName(rs.getString(2));
			/*request.setStatus(rs.getString(3));
			request.setType(rs.getString(4));
			request.setAssetName(rs.getString(5));
			request.setRemarks(rs.getString(6));
			request.setRequestDate(rs.getString(7));*/
			
			
			al.add(viewasset);
			
			
		}
		return al;
		
		
	}catch(SQLException se){
		se.printStackTrace();
	}
	return null;
	
}

public static ArrayList<ViewTeam> displayViewTeam() {
	
	try{
		String query="select user.user_id,user.first_name,user_asset.asset_id,asset2.asset_name from user left outer join user_asset on user.user_id=user_asset.user_id left outer join asset2 on asset2.asset_id=user_asset.asset_id where user.manager_id=201";
		PreparedStatement pmt=conn.prepareStatement(query);
		ResultSet rs=pmt.executeQuery();
		ArrayList<ViewTeam> al=new ArrayList<>();
		while(rs.next()){
			ViewTeam viewteam=new ViewTeam();
			/*System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));*/
			viewteam.setUserId(rs.getInt(1));
			viewteam.setFirstName(rs.getString(2));
			viewteam.setAssetId(rs.getInt(3));
			viewteam.setAssetName(rs.getString(4));
			
			/*request.setStatus(rs.getString(3));
			request.setType(rs.getString(4));
			request.setAssetName(rs.getString(5));
			request.setRemarks(rs.getString(6));
			request.setRequestDate(rs.getString(7));*/
			
			
			al.add(viewteam);
			
			
		}
		return al;
		
		
	}catch(SQLException se){
		se.printStackTrace();
	}
	return null;
	
}

public static ArrayList<Request> displayEmployeeRequests() {
	
	try{
		String query="Select * from request2 where status='pending'";
		PreparedStatement pmt=conn.prepareStatement(query);
		ResultSet rs=pmt.executeQuery();
		ArrayList<Request> al=new ArrayList<>();
		while(rs.next()){
			Request request=new Request();
			request.setRequestId(rs.getInt(1));
			request.setUserId(rs.getInt(2));
			request.setStatus(rs.getString(3));
			request.setType(rs.getString(4));
			request.setAssetName(rs.getString(5));
			request.setRemarks(rs.getString(6));
			request.setRequestDate(rs.getString(7));
			request.setResponseDate(rs.getString(8));
			
			al.add(request);
			
			
		}
		return al;
		
		
	}catch(SQLException se){
		se.printStackTrace();
	}
	return null;
	
}

public static boolean updateRequest(Request request) {
	
	try { 
		String query="update request2 set status='approved' where request_id=4";
		PreparedStatement pmt = conn.prepareStatement(query);
		int n = pmt.executeUpdate();
		//System.out.println(request.getRequestId());
		
		if (n > 0)
	       		return true;
		
	} 
	catch (SQLException se) {
		se.printStackTrace();
	}
	return false;

}
}
