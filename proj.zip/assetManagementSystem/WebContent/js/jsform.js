
 function signup_val()
   {
	/* var uid=document.getElementById('userId').value;*/
	   var mid=document.getElementById('managerId').value; 
   var firstname=document.getElementById('firstName').value;
   var lastname=document.getElementById('lastName').value;
   var email=document.getElementById('email').value;
   var password=document.getElementById('password').value;
   var shortid=document.getElementById('shortId').value;
   var mobile=document.getElementById('mobileNumber').value;
   var doj=document.getElementById('dateOfJoining').value;
  
   var ut=document.getElementById('usertype').value;
   
   
   var msg=document.getElementById('msg');
   
   
   
   var reg_name=/^[a-z,A-Z]{2,10}$/;
   var userid=/^[0-9]{2,10}$/;
   var reg_email=/^[a-z,A-Z,0-9,.,-,_,#]+[@][a-z,A-Z,0-9,.]+[.][a-z,A-Z,.]{1,3}$/;
   var var_password=/^[a-z,A-Z,0-9,.,-,_,#,@,*]{1,10}$/;
   var date=/^[a-z,A-Z,0-9,-]{1,15}$/;
   var mob=/^[0-9]{9,10}$/; 
   /* if(uid=="")
   {
	   //alert('Please Enter Name');
	   msg.innerHTML="Please Enter User ID";
	   return false;   
   }
   else if(!uid.match(userid))
   {
	msg.innerHTML="Please Enter Valid User ID";
	   return false;   
   }*/
     if(mid=="")
   {
	   //alert('Please Enter Name');
	   msg.innerHTML="Please Enter Manager ID";
	   return false;   
   }
   else if(!mid.match(userid))
   {
	msg.innerHTML="Please Enter Valid Manager ID";
	   return false;   
   }
   else if(firstname=="")
   {
	   //alert('Please Enter Name');
	   msg.innerHTML="Please Enter First Name";
	   return false;   
   }
   else if(!firstname.match(reg_name))
   {
	msg.innerHTML="Please Enter Valid First Name";
	   return false;   
   }
  
   else if(lastname=="")
   {
	   //alert('Please Enter Name');
	   msg.innerHTML="Please Enter Last Name";
	   return false;   
   }
   else if(!lastname.match(reg_name))
   {
	msg.innerHTML="Please Enter Valid Last Name";
	   return false;   
   } 
   else if(email=='')
   {
	msg.innerHTML="Please Enter Email Id";
	   return false;   
   }
   else if(!email.match(reg_email))
   {
	msg.innerHTML="Please Enter Valid email";
	   return false;   
   }
   else if(password=='')
   {
	msg.innerHTML="Please Enter Password";
	   return false;   
   }
   else if(!password.match(var_password))
   {
	msg.innerHTML="Please Enter Valid Password";
	   return false;   
   }
   else if(shortid=='')
   {
	   //alert('Please Enter Name');
	   msg.innerHTML="Please Enter Short id";
	   return false;   
   }
   else if(!shortid.match(reg_name))
   {
	msg.innerHTML="Please Enter Valid Short id";
	   return false;   
   }
   else if(mobile=='')
   {
	   //alert('Please Enter Name');
	   msg.innerHTML="Please Enter mobile";
	   return false;   
   }
   else if(!mobile.match(mob))
   {
	msg.innerHTML="Please Enter Valid Mobile";
	   return false;   
   }
   else if(doj=='')
   {
	   //alert('Please Enter Name');
	   msg.innerHTML="Please Select date";
	   return false;   
   }
   else if(!doj.match(date))
   {
	msg.innerHTML="Please Select Date";
	   return false;   
   }
  
   else if(ut=='')
   {
	   //alert('Please Enter Name');
	   msg.innerHTML="Please Enter Usertype";
	   return false;   
   }
   else if(!ut.match(reg_name))
   {
	msg.innerHTML="Please Enter Valid Usertype";
	   return false;   
   }
   
   else{
	   return true;
	   } 
   }
// JavaScript Document