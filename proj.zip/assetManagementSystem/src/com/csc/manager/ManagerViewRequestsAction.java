package com.csc.manager;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.Request;
import com.csc.service.ManagerService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class ManagerViewRequestsAction extends ActionSupport implements ModelDriven,ServletRequestAware{

ArrayList<Request> requestList=new ArrayList<>();
	HttpSession session;
	Request request=new Request();
	
	
	public ArrayList<Request> getRequestList() {
	return requestList;
}
public void setRequestList(ArrayList<Request> requestList) {
	this.requestList = requestList;
}
	public String execute() {
		session.getAttribute("uid");
		
		ManagerService rs=new ManagerService();
		request.setUserId((int)session.getAttribute("uid"));
		requestList=rs.displayRequests(request);
		session.setAttribute("rid", requestList.get(0).getRequestId());
	
	
		return SUCCESS;
	}
	@Override
	public Object getModel() {
		
		return requestList;
	}
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	}
}
