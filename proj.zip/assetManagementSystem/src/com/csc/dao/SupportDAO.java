package com.csc.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.csc.bean.AssetAndRequest;


public class SupportDAO {
	private static Connection conn;

	public SupportDAO() {
	}

	public static void connect() {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager
					.getConnection("jdbc:mysql://localhost/ams?"+"user=root&password=cscindia@123");
		} catch (ClassNotFoundException ce) {
			ce.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}// connect
	
	

	public static ArrayList<AssetAndRequest> displayRequest() {
		
		
			try { 
				String query = "select * from asset,request where asset.asset_name=request.asset_name and request.status='approved'";
			
				PreparedStatement pmt = conn.prepareStatement(query);
				ResultSet rs = pmt.executeQuery();
				ArrayList<AssetAndRequest> al = new ArrayList<>();
				while (rs.next()) {
					AssetAndRequest arr=new AssetAndRequest();
					
					arr.setAid(rs.getInt(1));
					
					arr.setAssetName(rs.getString(2));
					arr.setWarrenty(rs.getString(3));
					arr.setMake(rs.getString(5));
					arr.setPrice(rs.getInt(4));
					arr.setDescription(rs.getString(6));
					arr.setRequestId(rs.getInt(7));
					arr.setUserId(rs.getInt(8));
					arr.setStatus(rs.getString(9));
					arr.setType(rs.getString(10));
					arr.setRemarks(rs.getString(12));
					arr.setRequestDate(rs.getString(13));
					
					al.add(arr);
					
					
					
					
				}
				return al;
			
			} catch (SQLException se) {
				se.printStackTrace();
			}
			return null;
		
	
	}
	

	public static boolean updateRequest(AssetAndRequest arr) {
		try { 
			
			String query="update request set status='dispatched' where request_id=?";
			
			PreparedStatement pmt = conn.prepareStatement(query);
			pmt.setInt(1, arr.getRequestId());
			
			int n = pmt.executeUpdate();
			
			if (n > 0)
				/*updateUserasset(arr);*/
		       		return true;
			
			
		} 
		catch (SQLException se) {
			se.printStackTrace();
		}
		return false;
	}

	public static boolean updateUserasset(AssetAndRequest arr) {
		try{
			String query1="insert into user_asset values(?,?,null,null,'no status')";
			PreparedStatement pmt = conn.prepareStatement(query1);
			pmt.setInt(1, arr.getUserId());
			pmt.setInt(2, arr.getAid());
			//pmt.setString(3, arr.getStatus());
			//pmt.setInt(4, arr.getReturnDate());
			int n = pmt.executeUpdate();
			if (n > 0)
				return true;
		} 
		catch (SQLException se) {
			se.printStackTrace();
		} 
		
		
		
		
		
		// TODO Auto-generated method stub
		return false;
	}



	public static boolean updateAssetmanager(AssetAndRequest arr) {
		// TODO Auto-generated method stub
		return false;
	}

}
	


