package com.csc.support;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.AssetAndRequest;
import com.csc.service.SupportService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })

public class ViewRequestAction extends ActionSupport implements ServletRequestAware,ModelDriven
{ 
	HttpSession session;
	AssetAndRequest arr=new AssetAndRequest();
	
	ArrayList<AssetAndRequest> requestList=new ArrayList<>();
	
	public ArrayList<AssetAndRequest> getRequestList() {
		return requestList;
	}

	public void setRequestList(ArrayList<AssetAndRequest> requestList) {
		this.requestList = requestList;
	}

	public String execute() {
		
		
		SupportService as=new SupportService();
		requestList=as.displayRequest();
		session.setAttribute("rid", requestList.get(0).getRequestId());
		session.setAttribute("uid", requestList.get(0).getUserId());
		session.setAttribute("aid", requestList.get(0).getAid());
		//session.setAttribute("status", requestList.get(3).getStatus());
		return SUCCESS;
	}

	
	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		
		this.session=request.getSession();

	}

	@Override
	public Object getModel() {
		// TODO Auto-generated method stub
		return arr;
	}
		
}