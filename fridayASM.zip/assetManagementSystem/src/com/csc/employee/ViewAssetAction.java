package com.csc.employee;

public class ViewAssetAction {

}
