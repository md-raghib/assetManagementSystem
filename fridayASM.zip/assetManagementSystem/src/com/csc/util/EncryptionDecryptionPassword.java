package com.csc.util;

public class EncryptionDecryptionPassword {

		public static int p;
		public static int q=11;
		public static int phi;
		public static int n;
		public static int m;
		public static int e;
		public static int d;
		
		
		
		public String encrypt( String password){
			p= Integer.parseInt(password);
			n=p*q;
			phi=(p-1)*(q-1);
			e=gcd(p,q);
			d=compute(e,phi);
			return password;
			
		}



		private int compute(int e2, int phi2) {
			for(d=1;d<100;d++){
				if(((d*e2)%phi)==1){
					return d;
				}
				
			}
			return 0;
			
			
		}



		private int gcd(int p2, int q2) {
			int t;
			while(q2!=0){
				t=p2;
				p2=q2;
				q2=t%q2;
			}
			return p2;
			
		}
		
		
}
