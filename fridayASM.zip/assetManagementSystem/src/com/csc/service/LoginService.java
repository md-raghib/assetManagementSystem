package com.csc.service;

import com.csc.bean.User;

import com.csc.dao.LoginDAO;


public class LoginService {
	
	public User log(User user)
	{
		LoginDAO.connect();
		 LoginDAO.loginUser(user);
		 /*System.out.println(user);*/
		 return user;
		
		
	}
	
	
	
	
}
