package com.csc.admin;

import com.csc.bean.User;
import com.csc.service.AdminService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({ "serial", "rawtypes" })
public class UpdateUserAction extends ActionSupport implements ModelDriven {
	
	User user=new User();
	@Override
	public Object getModel() {
		// TODO Auto-generated method stub
		return user;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	public String execute(){
		AdminService as=new AdminService();
		as.update(user);
		
		
		
		return SUCCESS;
	}
	
}
