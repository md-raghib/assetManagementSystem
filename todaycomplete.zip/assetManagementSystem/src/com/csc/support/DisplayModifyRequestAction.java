package com.csc.support;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.AssetAndRequest;
import com.csc.service.SupportService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;


@SuppressWarnings({ "serial", "rawtypes" })
public class DisplayModifyRequestAction extends ActionSupport implements ModelDriven,ServletRequestAware
{
 AssetAndRequest arr=new AssetAndRequest();
HttpSession session;
 public AssetAndRequest getAssetAndRequest() {
		return arr;
	}

	public void setUser(AssetAndRequest arr) {
		this.arr = arr;
	}
	
	 public String execute() {
		
			SupportService as=new SupportService();
			 arr.setRequestId((int)session.getAttribute("rid"));
			 arr.setUserId((int)session.getAttribute("uid"));
			 arr.setAid((int)session.getAttribute("aid"));
			if(as.updateRequest(arr))
			{
				
					as.updateUserasset(arr);
					as.updateAssetmanager(arr);

					return SUCCESS;
				}
				
			
			
			else 
				return ERROR;
		}
	
	@Override
	public Object getModel() {
		
		return arr;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	}
	
}
