package com.csc.employee;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.csc.bean.Request;
import com.csc.service.EmployeeService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings("rawtypes")
public class RequestAction extends ActionSupport implements ModelDriven,ServletRequestAware{
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	HttpSession session;
	Request request=new Request();
	
	@Override
	public Object getModel() {
		
		return request;
	}
	public String execute() {
		session.getAttribute("uid");
		System.out.println(session.getAttribute("uid"));
		request.setUserId((int) session.getAttribute("uid"));
		EmployeeService as=new EmployeeService();
		if((as.requestAsset(request))!=false){
			return SUCCESS;
		}
		else
			return ERROR;
		
	}
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.session=request.getSession();
		
	} }


