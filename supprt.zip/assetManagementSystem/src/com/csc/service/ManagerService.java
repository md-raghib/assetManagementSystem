package com.csc.service;

import java.util.ArrayList;

import com.csc.bean.*;

import com.csc.dao.ManagerDAO;

public class ManagerService {
	public boolean requestAsset(Request request)
	{
		ManagerDAO.connect();
		boolean b= ManagerDAO.requestAsset(request);
		if(b){
		return true;
		}
		else
			return false;
}
public ArrayList<Request> displayStatus() {
		
		ManagerDAO.connect();
		ArrayList<Request> al= ManagerDAO.displayRequestStatus();
		return al;
	}	

public ArrayList<ViewAsset> displayAsset() {
	
	ManagerDAO.connect();
	ArrayList<ViewAsset> al= ManagerDAO.displayViewAsset();
	return al;
}


public ArrayList<Request> displayRequests() {
	
	ManagerDAO.connect();
	ArrayList<Request> al= ManagerDAO.displayEmployeeRequests();
	return al;
}	


public ArrayList<ViewTeam> displayTeam() {
	
	ManagerDAO.connect();
	ArrayList<ViewTeam> al= ManagerDAO.displayViewTeam();
	return al;
}	
public boolean updateRequest(Request request) {
	ManagerDAO.connect();
	boolean b=ManagerDAO.updateRequest(request);
	if(b){

		return true;
}

else	{
	return false;
} 

}	
}
