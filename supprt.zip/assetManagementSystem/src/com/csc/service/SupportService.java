package com.csc.service;
import java.util.ArrayList;
import com.csc.bean.AssetAndRequest;
import com.csc.dao.SupportDAO;

public class SupportService {

	public ArrayList<AssetAndRequest> displayRequest()
		{
			SupportDAO.connect();
			ArrayList<AssetAndRequest> al= SupportDAO.displayRequest();
				return al;
			}

	
		public boolean updateRequest(AssetAndRequest arr)
		{
			SupportDAO.connect();
			boolean b=SupportDAO.updateRequest(arr);
			if(b){
		
					return true;
			}
			
		else	{
				return false;
			} 
}


		public boolean updateUserasset(AssetAndRequest arr) {
			// TODO Auto-generated method stub
			SupportDAO.connect();
			boolean b=SupportDAO.updateUserasset(arr);
			if(b){
		
					return true;
			}
			
		else	{
				return false;
			} 
		}


		public boolean updateAssetmanager(AssetAndRequest arr) {
			// TODO Auto-generated method stub
			SupportDAO.connect();
			boolean b=SupportDAO.updateAssetmanager(arr);
			if(b){
		
					return true;
			}
			
		else	{
				return false;
			} 
		}


}
		
