package com.csc.support;

import com.csc.bean.AssetAndRequest;
import com.csc.service.SupportService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;


@SuppressWarnings({ "serial", "rawtypes" })
public class SupportAction extends ActionSupport implements ModelDriven {

	AssetAndRequest arr=new AssetAndRequest();

	@Override
	public Object getModel() {
		// TODO Auto-generated method stub
		return null;
	}	
	
	
	/*public String execute() {
		SupportService as=new SupportService();
		if((as.displayRequest())!=false){
			return SUCCESS;
		}
		else
			return ERROR;
	}
	
	@Override
	public Object getModel() {
		
		return arr;
	}
	
	I*/
}





		
	
	
	
	
	
	
	

