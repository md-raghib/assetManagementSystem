package com.csc.manager;

import com.csc.bean.Request;
import com.csc.service.ManagerService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings({"serial", "rawtypes"})
public class ManagerApproveRequestAction extends ActionSupport implements ModelDriven{

	
	Request request=new Request();

	public Request getRequest() {
		System.out.println(request);
		return request;
	}

	public void setRequest(Request request) {
		this.request = request;
	}


	 public String execute() {
			ManagerService ms=new ManagerService();
				if(ms.updateRequest(request))
				return SUCCESS;
				else
					return ERROR;
			}
		
		@Override
		public Object getModel() {
			
			return request;
		}
}
